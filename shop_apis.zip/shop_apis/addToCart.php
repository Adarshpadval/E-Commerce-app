<?php
require 'db/db.php';

// CORS headers
header("Access-Control-Allow-Origin: *"); // Allow requests from any origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allow specific methods
header("Access-Control-Allow-Headers: Content-Type, Authorization"); // Allow specific headers
header('Content-Type: application/json');

// Handle preflight requests (OPTIONS)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit;
}

// Get and validate input
$data = json_decode(file_get_contents('php://input'), true);


if (!isset($data['productId'], $data['quantity']) || !is_numeric($data['quantity'])) {
    http_response_code(400); 
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid input',
        'data' => $data
    ]);
    exit;
}

$userId = 1; // For demo purposes, this is hardcoded
$productId = (int)$data['productId'];
$quantity = (int)$data['quantity'];

if ($quantity < 1) {
    http_response_code(400); 
    echo json_encode(['status' => 'error', 'message' => 'Quantity must be at least 1']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) 
        VALUES (:user_id, :product_id, :quantity)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)");
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':product_id', $productId);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->execute();
    echo json_encode(['status' => 'success', 'message' => 'Item added to cart']);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
