<?php
// Database configuration
$host = 'localhost';  //  database host 
$dbname = 'shop';  //  database name
$username = 'root';  //  database username
$password = '';  //  database password

try {
    // Create a new PDO instance
    $pdo = new PDO(
        dsn: "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        username: $username,
        password: $password,
        options: [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Enable exceptions for errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,  // Set default fetch mode to associative array
            PDO::ATTR_EMULATE_PREPARES => false,  // Disable emulation of prepared statements
        ]
    );

    // Connection successful
    // echo "Connected to the database successfully!";
} catch (PDOException $e) {
    // Handle connection errors
    echo "Connection failed: " . $e->getMessage();
    exit;  // Stop further execution in case of connection failure
}
