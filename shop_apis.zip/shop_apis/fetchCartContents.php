<?php
require 'db/db.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

$userId = 1;  

if ($userId > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                c.product_id, 
                p.name, 
                p.price, 
                c.quantity, 
                GROUP_CONCAT(pi.image_url) AS images 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            LEFT JOIN product_images pi ON p.id = pi.product_id 
            WHERE c.user_id = :user_id 
            GROUP BY c.product_id, p.name, p.price, c.quantity
        ");
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($cartItems as &$item) {
            $item['images'] = explode(',', $item['images']);
        }

        echo json_encode(['status' => 'success', 'data' => $cartItems]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database error']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid user ID']);
}
?>
