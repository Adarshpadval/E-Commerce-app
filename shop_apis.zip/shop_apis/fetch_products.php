<?php
require 'db/db.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("
        SELECT p.id, p.name, p.price, i.image_url
        FROM products p
        LEFT JOIN product_images i ON p.id = i.product_id
    ");
    $products = $stmt->fetchAll();

    $groupedProducts = [];
    foreach ($products as $product) {
        $productId = $product['id'];
        if (!isset($groupedProducts[$productId])) {
            $groupedProducts[$productId] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'price' => $product['price'],
                'images' => []
            ];
        }
        $groupedProducts[$productId]['images'][] = $product['image_url'];
    }

    
    $groupedProducts = array_values($groupedProducts);

   
    echo json_encode(['status' => 'success', 'data' => $groupedProducts]);
} catch (PDOException $e) {
    
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
