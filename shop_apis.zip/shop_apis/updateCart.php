<?php
require 'db/db.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit; 
}

$data = json_decode(file_get_contents('php://input'), true);
if (!isset( $data['productId'], $data['quantity'])) {
    http_response_code(400); 
    echo json_encode(['status' => 'error', 'message' => 'Missing parameters']);
    exit;
}

$userId = 1;
$productId = (int)$data['productId'];
$quantity = (int)$data['quantity'];

// Validate quantity
if ($quantity < 0) {
    http_response_code(400); 
    echo json_encode(['status' => 'error', 'message' => 'Invalid quantity']);
    exit;
}

try {
    if ($quantity === 0) {
        $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = :user_id AND product_id = :product_id");
    } else {
        $stmt = $pdo->prepare("UPDATE cart SET quantity = :quantity WHERE user_id = :user_id AND product_id = :product_id");
    }
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':product_id', $productId);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->execute();
    echo json_encode(['status' => 'success', 'message' => 'Cart updated']);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
